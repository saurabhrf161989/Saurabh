package runner;



import cucumber.api.CucumberOptions;
import cucumber.api.testng.*;

import org.junit.AfterClass;
import org.junit.runner.RunWith;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;








@CucumberOptions(
		features="src/test/java/features",
		glue={"stepDefination"},
				plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/report.html"
				}
		)

		
public class TestRunner extends AbstractTestNGCucumberTests {


	

	
	/*@AfterClass
	 public static void writeExtentReport() {
	 
	 }*/
}